const Student = [
  {

    name: "Chaman",
    mobile: 987654321,
    id: '1'
  },
  {

    name: "Ayaan",
    mobile: 636526564,
    id: '2'
  }, {
    name: "Sam",
    mobile: 43245625,
    id: '3'

  }, {
    name: "Ravi",
    mobile: 765678769,
    id: '4'

  }
]
export default Student;