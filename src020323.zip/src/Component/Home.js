import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Button, Table } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
import { addTodo, deleteStudent } from "../services/action";
import { useDispatch } from "react-redux";


const mapStateToProps = (state) => {
  //console.log(state, "storedata")
  return {
    todos: state.todos.apiData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchData: () => dispatch(addTodo()),
  };
};

function Home({ todos, fetchData }) {
  const dispatch = useDispatch()
  useEffect(() => {
    fetchData();
  }, []);

  // const handleEdit=(id,name,mobile)=>{
  //   localStorage.setItem('name',name)
  //   localStorage.setItem('mobile',mobile)
  //   localStorage.setItem('id',id)

  // }

  return (
    <>
      <div style={{ margin: "3rem" }}>
        <h1>REDUX-CRUD</h1>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Name</th>
              <th>Mobile</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {todos && todos.length > 0
              ? todos.map((item, index) => {
                return (
                  <tr key={index}>
                    <td>{item.name}</td>
                    <td>{item.mobile}</td>
                    <td>
                      <Link to={`edit/${item.id}`}>
                        <Button >Edit</Button>
                      </Link>
                      &nbsp;
                      <Button variant="danger" onClick={() => dispatch(deleteStudent(item.id))}>
                        Delete
                      </Button>
                    </td>
                  </tr>
                );
              })
              : "No Data Avilable"}
          </tbody>
        </Table>
        <br>
        </br>
        <Link className="d-grid gap-2" to={'/create'}>
          <Button size="lg">Create</Button>
        </Link>
      </div>
    </>
  );
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);
