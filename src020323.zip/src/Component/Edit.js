import React, { useState, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { connect } from "react-redux";
import { studentInfo, updateStudent } from "../services/action";
import { useDispatch } from "react-redux";

const mapStateToProps = (state) => {
  // console.log(state, "edit page data")
  return {
    todos: state.todos.apiData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    getUserDetail: (newId) => dispatch(studentInfo(newId)),
  };
};

function Edit({ getUserDetail, todos }) {
  const dispatch = useDispatch()
  const [redirect, setRedirect] = useState(false)

  const { id } = useParams();
  //console.log(id, "kjbhjfds")
  useEffect(() => {
    getUserDetail(id);
  }, [])

  let index = todos.find((todos) => todos.id === id)
  // console.log(index.name, "fuggfue")
  const { name, mobile } = index

  const [value, setValue] = useState({
    name: name, mobile: mobile
  })

  const handleUpdate = (e) => {
    setValue({ ...value, [e.target.name]: e.target.value })
  }

  const navigate = useNavigate();
  const navigateHome = () => {

    navigate('/');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    Object.assign(value, { id: id })
    dispatch(updateStudent(value))
    setRedirect(true)

  };
  if (redirect) {
    return navigate("/");
  }


  return (
    <div>
      <Form className="d-grid gap-2" style={{ margin: "5rem" }}>
        <Button variant="info" onClick={navigateHome}>Home</Button>
        <h1>Update Record</h1>
        <Form.Group className="mb-3" controlId="formName">
          <Form.Control
            type="text"
            name="name"
            value={value.name}
            required
            onChange={handleUpdate}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formmobile">
          <Form.Control
            type="text"
            name="mobile"
            value={value.mobile}
            required
            onChange={handleUpdate}
          />
        </Form.Group>

        <Button variant="primary" type="submit" onClick={(e) => handleSubmit(e)}>
          Update
        </Button>
      </Form>
    </div>
  )
}

export default connect(mapStateToProps, mapDispatchToProps)(Edit)
