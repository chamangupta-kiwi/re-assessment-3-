import { FETCH_API_SUCCESS, ADD_STUDENT, DELETE_STUDENT, STUDENT_INFO, UPDATE_STUDENT } from './constraints'

import Students from "../Component/Student";
let apiData = Students

export const addTodo = () => {

  return {
    type: FETCH_API_SUCCESS,
    payload: apiData
  }

}

export const studentReg = (data) => {
  return {
    type: ADD_STUDENT,
    payload: data
  }
}

export const deleteStudent = (id) => {
  return {
    type: DELETE_STUDENT,
    payload: id
  }
}

export const studentInfo = (id) => {
  //  console.log(id, "action id")
  return {
    type: STUDENT_INFO,
    payload: id
  }
}

export const updateStudent = (data) => {
  // console.log(data, "edited")
  return {
    type: UPDATE_STUDENT,
    payload: data
  }
}