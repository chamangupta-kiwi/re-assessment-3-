import Student from "../Component/Student";

const initialState = {
  apiData: []
}
const todos = (state = initialState, action) => {
  // console.log("reducer",action)
  switch (action.type) {
    case "FETCH_API_SUCCESS":
      return {
        apiData: action.payload,
      }

    case "ADD_STUDENT":

      return {
        ...state,
        apiData: Student.push(action.payload)
      }

    case "DELETE_STUDENT":
      return {
        ...state,
        apiData: state.apiData.filter((Student) => Student.id !== action.payload)
      }
    case "STUDENT_INFO":
      // console.log(state, "====", action, "reducers")
      let studentDetail = state.apiData.filter((Student) => Student.id === action.payload)
      return {
        ...state,
        Student: (studentDetail.length > 0) ? studentDetail[0] : {}
      }
    case "UPDATE_STUDENT":
      console.log("====", action.payload, "reducers")
      return {
        ...state,
        apiData: state.apiData.map((Student) => Student.id === action.payload.id ? action.payload : Student)
      }
    default:
      return state;
  }
}
export default todos;

