import { createStore } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";

import rootReducer from "./services/root-reducer";

const store = createStore(
  rootReducer,composeWithDevTools()
);
// console.log(store,"ghfjjcfhjj")

export default store;
